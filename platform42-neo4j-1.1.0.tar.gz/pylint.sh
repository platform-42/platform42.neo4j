pylint plugins/modules/cleanup.py
pylint plugins/modules/query_read.py
pylint plugins/modules/vertex.py
pylint plugins/modules/edge.py

